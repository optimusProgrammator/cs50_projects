import re
import sys


def main():
    print(convert(input("Hours: ")))


def convert(s):
    pattern = r'^(1[0-2]|0?[1-9]):?([0-5][0-9])? (AM|PM) to (1[0-2]|0?[1-9]):?([0-5][0-9])? (AM|PM)$'
    match = re.match(pattern, s)

    if not match:
        raise ValueError("Invalid format")

    start_hour, start_minute, start_period, end_hour, end_minute, end_period = match.groups()

    start_minute = start_minute if start_minute else '00'
    end_minute = end_minute if end_minute else '00'

    start_hour_24 = convert_to_24_hour(start_hour, start_minute, start_period)
    end_hour_24 = convert_to_24_hour(end_hour, end_minute, end_period)

    return f"{start_hour_24} to {end_hour_24}"


def convert_to_24_hour(hour, minute, period):
    hour = int(hour)
    minute = int(minute)

    if hour == 12:
        hour = 0
    if period == 'PM':
        hour += 12

    return f"{hour:02}:{minute:02}"


if __name__ == "__main__":
    main()
