from fpdf import FPDF

class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 16)
        self.cell(0, 10, "CS50 Shirtificate", 0, 1, "C")

def main():
    name = input("Enter your name: ")

    # Create instance of FPDF class
    pdf = PDF(orientation='P', unit='mm', format='A4')
    pdf.add_page()

    # Set font for the name
    pdf.set_font("Arial", "B", 24)

    # Add shirt image
    pdf.image("shirtificate.png", x=0, y=60, w=210)

    # Calculate text width to center it on the image
    text_width = pdf.get_string_width(name) + 6
    pdf.set_xy((210 - text_width) / 2, 140)

    # Set text color to white
    pdf.set_text_color(255, 255, 255)

    # Add name on top of the shirt
    pdf.cell(text_width, 10, name, 0, 1, 'C')

    # Output the PDF to a file
    pdf.output("shirtificate.pdf")

if __name__ == "__main__":
    main()
