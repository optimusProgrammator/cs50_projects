from twttr import shorten

def main():
    test_cases()
    test_number()
    test_punctuation()

def test_cases():
    assert shorten("hello") == "hll"
    assert shorten("Hi there") == "H thr"
    assert shorten("HELLO") == "HLL"
    assert shorten("HelLo") == "HlL"

def test_number():
    assert shorten("1234567890") == "1234567890"

def test_punctuation():
    assert shorten("!,.?") == "!,.?"
