from cs50 import get_int


def main():
    height = get_int("Height: ")
    while height < 1 or height > 8:
        height = get_int("Height: ")
    print_pyramid(height)


def print_pyramid(height):
    for row in range(height):
        for space in range(height - row - 1):
            print(" ", end="")
        for column in range(row + 1):
            print("#", end="")
        print()


if __name__ == "__main__":
    main()
