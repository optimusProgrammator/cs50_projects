"""
PYTHON PROGRAM : DEEP THOUGHT
"""

def main():

    question = input("What is the answer to the Great Question of Life, the Universe and Everything : ")
    reply = answer(question)
    print(reply)

def answer(answer):
    if answer.lower() == "forty two" or answer.lower() == "forty-two" or answer.strip() == "42":
        return "Yes"
    else:
        return "No"

if __name__ == "__main__":
    main()

