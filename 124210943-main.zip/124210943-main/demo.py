import random

elements = {
    'hydrogen': {
        'atomic_mass': 1.008,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '+1',
        'orbital': 's'
    },
    'helium': {
        'atomic_mass': 4.0026,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 's'
    },
    'lithium': {
        'atomic_mass': 6.94,
        'chemical_group': 'Alkali Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 's'
    },
    'beryllium': {
        'atomic_mass': 9.0122,
        'chemical_group': 'Alkaline Earth Metal',
        'bond_type': 'Covalent',
        'charge': '+2',
        'orbital': 's'
    },
    'boron': {
        'atomic_mass': 10.81,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'p'
    },
    'carbon': {
        'atomic_mass': 12.011,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'p'
    },
    'nitrogen': {
        'atomic_mass': 14.007,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '-3',
        'orbital': 'p'
    },
    'oxygen': {
        'atomic_mass': 15.999,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '-2',
        'orbital': 'p'
    },
    'fluorine': {
        'atomic_mass': 18.998,
        'chemical_group': 'Halogen',
        'bond_type': 'Covalent',
        'charge': '-1',
        'orbital': 'p'
    },
    'neon': {
        'atomic_mass': 20.180,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 'p'
    },
    'sodium': {
        'atomic_mass': 22.990,
        'chemical_group': 'Alkali Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 's'
    },
    'magnesium': {
        'atomic_mass': 24.305,
        'chemical_group': 'Alkaline Earth Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 's'
    },
    'aluminum': {
        'atomic_mass': 26.982,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'p'
    },
    'silicon': {
        'atomic_mass': 28.085,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'p'
    },
    'phosphorus': {
        'atomic_mass': 30.974,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '-3',
        'orbital': 'p'
    },
    'sulfur': {
        'atomic_mass': 32.06,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '-2',
        'orbital': 'p'
    },
    'chlorine': {
        'atomic_mass': 35.45,
        'chemical_group': 'Halogen',
        'bond_type': 'Covalent',
        'charge': '-1',
        'orbital': 'p'
    },
    'argon': {
        'atomic_mass': 39.948,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 'p'
    },
    'potassium': {
        'atomic_mass': 39.098,
        'chemical_group': 'Alkali Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 's'
    },
    'calcium': {
        'atomic_mass': 40.078,
        'chemical_group': 'Alkaline Earth Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 's'
    },
    'scandium': {
        'atomic_mass': 44.956,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'd'
    },
    'titanium': {
        'atomic_mass': 47.867,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'd'
    },
    'vanadium': {
        'atomic_mass': 50.942,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+5',
        'orbital': 'd'
    },
    'chromium': {
        'atomic_mass': 51.996,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'd'
    },
    'manganese': {
        'atomic_mass': 54.938,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+2',
        'orbital': 'd'
    },
    'iron': {
        'atomic_mass': 55.845,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 'd'
    },
    'cobalt': {
        'atomic_mass': 58.933,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+2',
        'orbital': 'd'
    },
    'nickel': {
        'atomic_mass': 58.693,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+2',
        'orbital': 'd'
    },
    'copper': {
        'atomic_mass': 63.546,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 'd'
    },
    'zinc': {
        'atomic_mass': 65.38,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 'd'
    },
    'gallium': {
        'atomic_mass': 69.723,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'p'
    },
    'germanium': {
        'atomic_mass': 72.63,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'p'
    },
    'arsenic': {
        'atomic_mass': 74.922,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '-3',
        'orbital': 'p'
    },
    'selenium': {
        'atomic_mass': 78.971,
        'chemical_group': 'Nonmetal',
        'bond_type': 'Covalent',
        'charge': '-2',
        'orbital': 'p'
    },
    'bromine': {
        'atomic_mass': 79.904,
        'chemical_group': 'Halogen',
        'bond_type': 'Covalent',
        'charge': '-1',
        'orbital': 'p'
    },
    'krypton': {
        'atomic_mass': 83.798,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 'p'
    },
    'rubidium': {
        'atomic_mass': 85.468,
        'chemical_group': 'Alkali Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 's'
    },
    'strontium': {
        'atomic_mass': 87.62,
        'chemical_group': 'Alkaline Earth Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 's'
    },
    'yttrium': {
        'atomic_mass': 88.906,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'd'
    },
    'zirconium': {
        'atomic_mass': 91.224,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'd'
    },
    'niobium': {
        'atomic_mass': 92.906,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+5',
        'orbital': 'd'
    },
    'molybdenum': {
        'atomic_mass': 95.95,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+6',
        'orbital': 'd'
    },
    'technetium': {
        'atomic_mass': 98.907,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+7',
        'orbital': 'd'
    },
    'ruthenium': {
        'atomic_mass': 101.07,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'd'
    },
    'rhodium': {
        'atomic_mass': 102.91,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'd'
    },
    'palladium': {
        'atomic_mass': 106.42,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+2',
        'orbital': 'd'
    },
    'silver': {
        'atomic_mass': 107.87,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 'd'
    },
    'cadmium': {
        'atomic_mass': 112.41,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 'd'
    },
    'indium': {
        'atomic_mass': 114.82,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'p'
    },
    'tin': {
        'atomic_mass': 118.71,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'p'
    },
    'antimony': {
        'atomic_mass': 121.76,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '-3',
        'orbital': 'p'
    },
    'tellurium': {
        'atomic_mass': 127.60,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '-2',
        'orbital': 'p'
    },
    'iodine': {
        'atomic_mass': 126.90,
        'chemical_group': 'Halogen',
        'bond_type': 'Covalent',
        'charge': '-1',
        'orbital': 'p'
    },
    'xenon': {
        'atomic_mass': 131.29,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 'p'
    },
    'cesium': {
        'atomic_mass': 132.91,
        'chemical_group': 'Alkali Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 's'
    },
    'barium': {
        'atomic_mass': 137.33,
        'chemical_group': 'Alkaline Earth Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 's'
    },
    'lanthanum': {
        'atomic_mass': 138.91,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'cerium': {
        'atomic_mass': 140.12,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'praseodymium': {
        'atomic_mass': 140.91,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'neodymium': {
        'atomic_mass': 144.24,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'promethium': {
        'atomic_mass': 145.0,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'samarium': {
        'atomic_mass': 150.36,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'europium': {
        'atomic_mass': 151.96,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'gadolinium': {
        'atomic_mass': 157.25,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'terbium': {
        'atomic_mass': 158.93,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'dysprosium': {
        'atomic_mass': 162.50,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'holmium': {
        'atomic_mass': 164.93,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'erbium': {
        'atomic_mass': 167.26,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'thulium': {
        'atomic_mass': 168.93,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'ytterbium': {
        'atomic_mass': 173.05,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'lutetium': {
        'atomic_mass': 174.97,
        'chemical_group': 'Lanthanide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'hafnium': {
        'atomic_mass': 178.49,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'd'
    },
    'tantalum': {
        'atomic_mass': 180.95,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+5',
        'orbital': 'd'
    },
    'tungsten': {
        'atomic_mass': 183.84,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+6',
        'orbital': 'd'
    },
    'rhenium': {
        'atomic_mass': 186.21,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+7',
        'orbital': 'd'
    },
    'osmium': {
        'atomic_mass': 190.23,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'd'
    },
    'iridium': {
        'atomic_mass': 192.22,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'd'
    },
    'platinum': {
        'atomic_mass': 195.08,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+2',
        'orbital': 'd'
    },
    'gold': {
        'atomic_mass': 196.97,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+1',
        'orbital': 'd'
    },
    'mercury': {
        'atomic_mass': 200.59,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 'd'
    },
    'thallium': {
        'atomic_mass': 204.38,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'p'
    },
    'lead': {
        'atomic_mass': 207.2,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'p'
    },
    'bismuth': {
        'atomic_mass': 208.98,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Covalent',
        'charge': '+3',
        'orbital': 'p'
    },
    'polonium': {
        'atomic_mass': 209.0,
        'chemical_group': 'Metalloid',
        'bond_type': 'Covalent',
        'charge': '-2',
        'orbital': 'p'
    },
    'astatine': {
        'atomic_mass': 210.0,
        'chemical_group': 'Halogen',
        'bond_type': 'Covalent',
        'charge': '-1',
        'orbital': 'p'
    },
    'radon': {
        'atomic_mass': 222.0,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 'p'
    },
    'francium': {
        'atomic_mass': 223.0,
        'chemical_group': 'Alkali Metal',
        'bond_type': 'Ionic',
        'charge': '+1',
        'orbital': 's'
    },
    'radium': {
        'atomic_mass': 226.0,
        'chemical_group': 'Alkaline Earth Metal',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 's'
    },
    'actinium': {
        'atomic_mass': 227.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'thorium': {
        'atomic_mass': 232.04,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+4',
        'orbital': 'f'
    },
    'protactinium': {
        'atomic_mass': 231.04,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+5',
        'orbital': 'f'
    },
    'uranium': {
        'atomic_mass': 238.03,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+6',
        'orbital': 'f'
    },
    'neptunium': {
        'atomic_mass': 237.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+5',
        'orbital': 'f'
    },
    'plutonium': {
        'atomic_mass': 244.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+4',
        'orbital': 'f'
    },
    'americium': {
        'atomic_mass': 243.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'curium': {
        'atomic_mass': 247.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'berkelium': {
        'atomic_mass': 247.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'californium': {
        'atomic_mass': 251.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'einsteinium': {
        'atomic_mass': 252.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'fermium': {
        'atomic_mass': 257.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'mendelevium': {
        'atomic_mass': 258.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'nobelium': {
        'atomic_mass': 259.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+2',
        'orbital': 'f'
    },
    'lawrencium': {
        'atomic_mass': 262.0,
        'chemical_group': 'Actinide',
        'bond_type': 'Ionic',
        'charge': '+3',
        'orbital': 'f'
    },
    'rutherfordium': {
        'atomic_mass': 267.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+4',
        'orbital': 'd'
    },
    'dubnium': {
        'atomic_mass': 270.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+5',
        'orbital': 'd'
    },
    'seaborgium': {
        'atomic_mass': 271.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+6',
        'orbital': 'd'
    },
    'bohrium': {
        'atomic_mass': 270.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+7',
        'orbital': 'd'
    },
    'hassium': {
        'atomic_mass': 277.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+8',
        'orbital': 'd'
    },
    'meitnerium': {
        'atomic_mass': 278.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+9',
        'orbital': 'd'
    },
    'darmstadtium': {
        'atomic_mass': 281.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+10',
        'orbital': 'd'
    },
    'roentgenium': {
        'atomic_mass': 282.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+11',
        'orbital': 'd'
    },
    'copernicium': {
        'atomic_mass': 285.0,
        'chemical_group': 'Transition Metal',
        'bond_type': 'Covalent',
        'charge': '+12',
        'orbital': 'd'
    },
    'nihonium': {
        'atomic_mass': 286.0,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Ionic',
        'charge': '+13',
        'orbital': 'p'
    },
    'flerovium': {
        'atomic_mass': 289.0,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Ionic',
        'charge': '+14',
        'orbital': 'p'
    },
    'moscovium': {
        'atomic_mass': 290.0,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Ionic',
        'charge': '+15',
        'orbital': 'p'
    },
    'livermorium': {
        'atomic_mass': 293.0,
        'chemical_group': 'Post-transition Metal',
        'bond_type': 'Ionic',
        'charge': '+16',
        'orbital': 'p'
    },
    'tennessine': {
        'atomic_mass': 294.0,
        'chemical_group': 'Halogen',
        'bond_type': 'Covalent',
        'charge': '-1',
        'orbital': 'p'
    },
    'oganesson': {
        'atomic_mass': 294.0,
        'chemical_group': 'Noble Gas',
        'bond_type': 'None',
        'charge': '0',
        'orbital': 'p'
    }
}

def get_elements_by_difficulty(difficulty):
    if difficulty == 'easy':
        return dict(list(elements.items())[:20])
    elif difficulty == 'medium':
        return dict(list(elements.items())[:60])
    elif difficulty == 'hard':
        return elements
    else:
        print("Invalid difficulty level.")
        return None

def display_table(attributes):
    # Determine the maximum width for each column
    attr_width = max(len(attr) for attr in attributes) + 2
    val_width = max(len(str(value)) for value in attributes.values()) + 2

    print("\n" + "-"*(attr_width + val_width + 7))
    print(f"| {'Attribute'.ljust(attr_width)} | {'Value'.ljust(val_width)} |")
    print("-"*(attr_width + val_width + 7))

    for attr, value in attributes.items():
        print(f"| {attr.ljust(attr_width)} | {str(value).ljust(val_width)} |")

    print("-"*(attr_width + val_width + 7) + "\n")


print("Welcome to Elementle! Choose a difficulty level: easy, medium, or hard.\n")
difficulty = input("Enter difficulty: ").strip().lower()
element_subset = get_elements_by_difficulty(difficulty)

if element_subset is None:
    print("Exiting game due to invalid difficulty level.")
else:
    target_element = random.choice(list(element_subset.keys()))
    revealed_attributes = {key: '???' for key in element_subset[target_element]}

    attempts = 7
    hint_used = False

    print("Guess the element based on its attributes.")

    while attempts > 0:
        display_table(revealed_attributes)

        guess = input(f"Attempt {8 - attempts}/7 - Enter your element guess: ").strip().lower()

        if guess not in element_subset:
            print("Invalid element. Please try again.")
            continue

        guessed_element_attributes = element_subset[guess]

        for attribute in guessed_element_attributes:
            if guessed_element_attributes[attribute] == element_subset[target_element][attribute]:
                revealed_attributes[attribute] = element_subset[target_element][attribute]

        if guess == target_element:
            display_table(revealed_attributes)
            print(f"Congratulations! You've guessed the correct element: {target_element.capitalize()}.")
            break

        attempts -= 1

        if attempts == 3 and not hint_used:
            want_hint = input("You've completed your 4th attempt. Would you like a hint? (yes/no): ").strip().lower()
            if want_hint == 'yes':
                hidden_attributes = [attr for attr, value in revealed_attributes.items() if value == '???']
                if hidden_attributes:
                    random_attribute = random.choice(hidden_attributes)
                    revealed_attributes[random_attribute] = element_subset[target_element][random_attribute]
                    print(f"Hint: The {random_attribute} of the element is {element_subset[target_element][random_attribute]}.")
                else:
                    print("All attributes are already revealed!")
                hint_used = True

        if attempts == 0:
            print(f"Sorry! You've run out of attempts. The correct element was: {target_element.capitalize()}.")
            break

    print("Game Over.")
