import re
import sys

def main():

    address = input("IPv4 Address: ")

    validation = validate(address)

    print(validation)


def validate(ip):

    pattern = re.compile(r'^(\d{1,3}\.){3}\d{1,3}$')

    if not pattern.match(ip):
        return False

    parts = ip.split('.')
    for part in parts:
        # Ensure each part is an integer and in the range 0-255
        try:
            if not 0 <= int(part) <= 255:
                return False
        except ValueError:
            return False
    return True

if __name__ == "__main__":
    main()

