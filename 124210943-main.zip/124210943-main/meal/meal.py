"""
PYTHON PROGRAM : MEAL TIME
"""

def main():
    answer = input("What time is it?")
    meal = convert(answer)

    if meal >= 7 and meal <= 8:
        print("breakfast Time")

    if meal >= 12 and meal <= 13:
        print("lunch time")

    if meal >= 18 and meal <= 19:
        print("dinner time")


def convert(time):
    hour, minute = time.split(":")
    new_minute = float(minute) / 60
    sum = float(hour) + new_minute
    return sum


if __name__ == "__main__":
    main()
