"""
In the United States, dates are typically formatted in month-day-year order (MM/DD/YYYY),
otherwise known as middle-endian order, which is arguably bad design. Dates in that format
can’t be easily sorted because the date’s year comes last instead of first.
Try sorting, for instance, 2/2/1800, 3/3/1900, and 1/1/2000 chronologically in any program
(e.g., a spreadsheet). Dates in that format are also ambiguous. Harvard was founded on September 8, 1636,
but 9/8/1636 could also be interpreted as August 9, 1636!

Fortunately, computers tend to use ISO 8601, an international standard that
prescribes that dates should be formatted in year-month-day (YYYY-MM-DD) order,
no matter the country, formatting years with four digits, months with two digits,
and days with two digits, “padding” each with leading zeroes as needed.

In a file called outdated.py, implement a program that prompts the user for a
date, anno Domini, in month-day-year order, formatted like 9/8/1636 or September 8, 1636,
wherein the month in the latter might be any of the values in the list below:
"""

# List of month names
months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]

def validate_and_format_date(date_str):
    # For dates in MM/DD/YYYY format
    if "/" in date_str:
        parts = date_str.split("/")
        if len(parts) == 3:
            month, day, year = parts
            if month.isdigit() and day.isdigit() and year.isdigit():
                month = int(month)
                day = int(day)
                year = int(year)
                if 1 <= month <= 12 and 1 <= day <= 31:
                    return f"{year:04}-{month:02}-{day:02}"

    # For dates in "Month DD, YYYY" format
    elif "," in date_str:
        parts = date_str.split(" ")
        if len(parts) == 3:
            month_str, day_str, year_str = parts
            day_str = day_str.rstrip(",")
            if day_str.isdigit() and year_str.isdigit() and month_str in months:
                month = months.index(month_str) + 1
                day = int(day_str)
                year = int(year_str)
                if 1 <= day <= 31:
                    return f"{year:04}-{month:02}-{day:02}"

    return None

def main():
    while True:
        date_str = input("Enter a date (MM/DD/YYYY or Month DD, YYYY): ").strip()
        formatted_date = validate_and_format_date(date_str)
        if formatted_date:
            print(formatted_date)
            break
        else:
            print("Invalid date format. Please try again.")

if __name__ == "__main__":
    main()
