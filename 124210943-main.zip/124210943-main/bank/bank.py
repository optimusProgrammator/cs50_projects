
def main():
    greeting = input("Greeting: ")
    amount = reply(greeting)
    print(amount)

def reply(answer):
    match answer.strip():
        case "Hello" | "Hello, Newman":
            return "$0"
        case "How you doing?":
            return "$20"
        case "What's happening?":
            return "$100"
        case _:
            return "$100"


if __name__ == "__main__":
    main()
