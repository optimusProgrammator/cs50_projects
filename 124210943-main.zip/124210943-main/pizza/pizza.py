import sys
import csv
from tabulate import tabulate

def main():
    check_arg()

    filename = sys.argv[1]
    table = []


    try:
        with open(filename, "r") as csvfile:
            lines = csv.reader(csvfile)
            for row in lines:
                table.append(row)
            print(table)
    except FileNotFoundError:
        sys.exit("File does not exist")

    print(tabulate(table[1:], headers=table[0], tablefmt = "grid"))

def check_arg():
    if len(sys.argv) != 2:
        if len(sys.argv) < 2:
            sys.exit("Too few command-line arguments")
        else:
            sys.exit("Too many command-line arguments")

    if not sys.argv[1].endswith(".csv"):
        sys.exit("Not a CSV file")

if __name__ == "__main__":
    main()
