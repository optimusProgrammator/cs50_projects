"""
STRING PROGRAM : INDOOR VOICE
CREATED ON JULY 2, 2024
"""

string = input("Did you say something? : ")

quiet = string.lower()
print(quiet)
