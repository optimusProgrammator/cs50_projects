#include <cs50.h>
#include <stdio.h>

int main(void)
{
    string name = get_string("What's your name? "); //This is where the user inputs thier name.
    printf("Hello, %s\n", name); // The printed output, along with "Hello" and the name input
}