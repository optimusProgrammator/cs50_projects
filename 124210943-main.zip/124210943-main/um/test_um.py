import pytest
from um import count

def test_single_um():
    assert count("um") == 1
    assert count("Um") == 1
    assert count("UM") == 1

def test_multiple_ums():
    assert count("um, um, um") == 3
    assert count("Um, um, UM") == 3
    assert count("um... um... UM!") == 3

def test_um_in_words():
    assert count("yummy") == 0
    assert count("umbrella") == 0
    assert count("minimum") == 0

def test_um_with_punctuation():
    assert count("hello, um, world") == 1
    assert count("Um... what are you doing?") == 1
    assert count("This is, um, interesting.") == 1

def test_no_um():
    assert count("hello world") == 0
    assert count("This is interesting.") == 0

def test_edge_cases():
    assert count("") == 0
    assert count("UMm um umm") == 1

if __name__ == "__main__":
    pytest.main()
