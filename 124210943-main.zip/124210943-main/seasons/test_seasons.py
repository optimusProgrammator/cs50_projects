from seasons import check

def main():
    test()

def test():
    assert check("1998-03-03") == ("1998", "03", "03")
    assert check("1998-3-3") == None
    assert check("March 3, 1998") == None

if __name__ == "__main__":
    main()
