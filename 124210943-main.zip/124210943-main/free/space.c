#include <cs50.h>
#include <stdio.h>
#include <string.h>

typedef struct
{
    string position;
    string playerlist;
}
goldenstatewarriors;

int main(void)
{
    goldenstatewarriors player[5];

    player[0].position = "Point Guard";
    player[0].playerlist = "Stephen Curry, Chris Paul, Ty Jerome, Lester Quinones";

    player[1].position = "Shooting Guard";
    player[1].playerlist = "Klay Thompson, Brandin Podziemski, Gary Payton II ";

    player[2].position = "Small Forward";
    player[2].playerlist = "Andrew Wiggins, Moses Moody, Anthony Lamb";

    player[3].position = "Point Forward";
    player[3].playerlist = "Draymond Green, Jonathan Kuminga ";

    player[4].position = "Center";
    player[4].playerlist = "Kevon Looney, Trayce Jackson-Davis, Reggie Perry";


    // Search for name
    string position = get_string("Position for Golden State: ");
    for (int i = 0; i < 5; i++)
    {
        if (strcmp(player[i].position, position) == 0)
        {
            printf(" \nList: %s\n \n", player[i].playerlist);
            return 0;
        }
    }
    printf("Not found\n");
    return 1;
}