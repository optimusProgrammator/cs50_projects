from cs50 import get_int, get_string

valid_choices = ['A', 'S', 'M', 'D']
what_operation = ""

while what_operation not in valid_choices:
    what_operation = get_string("Hello. What operation would you like to perform? (A for Addition, S for Subtraction, M for Multiplication, D for Division): ")
    if what_operation not in valid_choices:
        print("Invalid operation choice. Please choose 'A', 'S', 'M', or 'D'.")

if what_operation == 'A':
    # Prompt user for x
    x = get_int("First Number: ")

    # Prompt user for y
    y = get_int("Second Number: ")

    # Perform addition
    print(x + y)

elif what_operation == 'S':
    # Prompt user for x
    x = get_int("First Number: ")

    # Prompt user for y
    y = get_int("Second Number: ")

    # Perform subtraction
    print(x - y)

elif what_operation == 'M':
    # Prompt user for x
    x = get_int("First Number: ")

    # Prompt user for y
    y = get_int("Second Number: ")

    # Perform multiplication
    print(x * y)

elif what_operation == 'D':
    # Prompt user for x
    x = get_int("First Number: ")

    # Prompt user for y
    y = get_int("Second Number: ")

    # Perform division
    if y != 0:
        print(x / y)
    else:
        print("Error: Cannot divide by zero.")
