from cs50 import get_int

def main():
    times = get_int("How many times do you want to meow? : ")
    meow(times)

def meow(n):
    for count in range(n):
        print("MEOW")

main()