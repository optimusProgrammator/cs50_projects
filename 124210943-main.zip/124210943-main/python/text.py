text = input("Write text: ")

words = text.split()

for word in words[2:7]:
    print(word)
print()
