import csv

# Get name and number
name = input("Name: ")
birthday = input("Birthday (month, day, year): ")

confirm_print = input(f"Name: {name}, Birthday: {birthday}\nConfirm print to CSV? (yes or no) : ")

# Open CSV file
if confirm_print == "yes":
    with open("birthday.csv", "a") as file:
        # Print to file
        writer = csv.writer(file)
        writer.writerow([name, birthday])
elif confirm_print == "no":
    pass  # Do nothing if user doesn't confirm
