import csv

with open("birthday.csv", "r") as file:
    reader = csv.DictReader(file)

    # Print the header row to check the column names
    print(reader.fieldnames)

    for row in reader:
        print(row[' birthday'])  # Note the space before 'birthday'
