from cs50 import get_int

# Prompt user for integers
fiona = get_int("What's Fiona's score? ")
justin = get_int("What's Justin's score? ")

# Compare integers
if fiona < justin:
    print("Justin, you're the best! You have a score of", justin, "which is higher than Fiona. Good job!")
elif fiona > justin:
    print("Justin, do your best next time! Fiona has a score of", fiona, "which is higher than yours. Beware!")
else:
    print("Fiona and Justin, your scores are equal.")

