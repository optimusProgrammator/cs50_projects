"""
STRINGS PROGRAM : FACES
CREATED ON JULY 2, 2024
"""

def main():

    happy = "🙂"
    sad = "🙁"
    string = input()
    words = string.split()

    if ":)" in words:
        new_string = string.replace(":)", happy)
        print(new_string)

    if ":(" in words:
        new_string = string.replace(":(", sad)
        print(new_string)

    if ":(" in words and ":(" in words :
        new_string = string.replace(":)", happy).replace(":(", sad)
        print(new_string)


main()
