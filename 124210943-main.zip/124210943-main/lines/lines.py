"""
Even so, in a file called lines.py, implement a program
that expects exactly one command-line argument, the name (or path)
of a Python file, and outputs the number of lines of code in that file,
excluding comments and blank lines. If the user does not specify exactly one command-line argument,
or if the specified file’s name does not end in .py, or if the specified file does not exist,
the program should instead exit via sys.exit.
"""

import sys

def main():
    check_arg()

    filename = sys.argv[1]

    try:
        with open(filename, "r") as file:
            lines = file.readlines()
    except FileNotFoundError:
        sys.exit("File does not exist")

    count = 0
    for line in lines:
        if not check_line(line):
            count += 1

    print(count)

def check_arg():
    if len(sys.argv) != 2:
        if len(sys.argv) < 2:
            sys.exit("Too few command-line arguments")
        else:
            sys.exit("Too many command-line arguments")

    if not sys.argv[1].endswith(".py"):
        sys.exit("Not a Python file")

def check_line(line):
    stripped_line = line.strip()
    if not stripped_line or stripped_line.startswith("#"):
        return True
    return False

if __name__ == "__main__":
    main()
