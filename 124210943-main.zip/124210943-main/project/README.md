# PROJECT TITLE : ELEMENTLE
    #### Video Demo:  <https://youtu.be/PQ7cgQGEprk>
    #### Description:

    The educational game Elementle is based on the popular word game Wordle and focuses on chemistry and the periodic table of elements. In this game, players must guess the correct element using hidden characteristics such as the element's chemical category, atomic number, and symbol. The game has three difficulty settings—easy, medium, and hard—each with different options available to players. Players have seven tries to guess the right element and can choose to get a hint after their fourth try to help them narrow down their guesses. Elementle combines entertainment and education, helping players become familiar with important features of the periodic table.

    In the command-line game Elementle, the player must guess a target element that is generated dynamically. Gamers can uncover some of the element's characteristics by using inference and hints. The game's design guarantees a fair challenge: the hard mode includes every element in the periodic table, making it appropriate for chemistry enthusiasts, while the easy mode concentrates on the first 20 elements, which are frequently more familiar to beginners. All skill levels will find something interesting to play, thanks to the dynamic difficulty and hint system that keep things from getting too hard. With this format, Elementle encourages players to learn about the properties of elements, such as atomic numbers and categories, while providing a flexible learning environment.




