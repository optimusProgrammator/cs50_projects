from project import get_elements_by_difficulty, handle_guess

elements = {
    'hydrogen': {'symbol': 'H', 'atomic_number': 1, 'category': 'nonmetal'},
    'helium': {'symbol': 'He', 'atomic_number': 2, 'category': 'noble gas'},
    'lithium': {'symbol': 'Li', 'atomic_number': 3, 'category': 'alkali metal'},
    'beryllium': {'symbol': 'Be', 'atomic_number': 4, 'category': 'alkaline earth metal'},
}

def test_get_elements_by_difficulty():
    """Test difficulty levels for element selection."""
    assert len(get_elements_by_difficulty('easy')) == 20
    assert len(get_elements_by_difficulty('medium')) == 60
    assert len(get_elements_by_difficulty('hard')) == len(elements)
    assert get_elements_by_difficulty('invalid') is None

def test_handle_guess():
    """Test guess handling and attribute revealing."""
    revealed_attributes = {'symbol': '???', 'atomic_number': '???', 'category': '???'}
    element_subset = elements

    # Test incorrect guess
    assert not handle_guess('helium', 'hydrogen', revealed_attributes, element_subset)
    assert revealed_attributes == {'symbol': '???', 'atomic_number': '???', 'category': '???'}

    # Test correct guess
    assert handle_guess('hydrogen', 'hydrogen', revealed_attributes, element_subset)
    assert revealed_attributes == {'symbol': 'H', 'atomic_number': 1, 'category': 'nonmetal'}

def test_display_table(capsys):
    """Test the display of the attributes table."""
    from project import display_table
    attributes = {'symbol': 'H', 'atomic_number': 1, 'category': 'nonmetal'}

    display_table(attributes)

    captured = capsys.readouterr()
    assert "Attribute" in captured.out
    assert "Value" in captured.out
    assert "symbol" in captured.out
