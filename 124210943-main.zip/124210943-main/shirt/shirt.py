import sys
import os
from PIL import Image, ImageOps

# Function to check if the file extension is valid
def valid_extension(filename):
    return filename.lower().endswith(('.jpg', '.jpeg', '.png'))

# Check the number of command-line arguments
if len(sys.argv) != 3:
    sys.exit("Usage: python shirt.py input_image output_image")

input = sys.argv[1]
output = sys.argv[2]

# Check if the input and output files have valid extensions
if not valid_extension(input):
    sys.exit("Invalid input")
if not valid_extension(output):
    sys.exit("Invalid output")

# Check if the input and output files have the same extension
input_ext = os.path.splitext(input)[1].lower()
output_ext = os.path.splitext(output)[1].lower()
if input_ext != output_ext:
    sys.exit("Input and output have different extensions")

# Check if the input file exists
if not os.path.isfile(input):
    sys.exit("Input does not exist")

try:
    # Open the input image and the shirt image
    input_image = Image.open(input)
    shirt_image = Image.open("shirt.png")

    # Resize and crop the input image to the size of the shirt image
    size = shirt_image.size
    input_image = ImageOps.fit(input_image, size)

    # Overlay the shirt image on the input image
    input_image.paste(shirt_image, shirt_image)

    # Save the result to the output file
    input_image.save(output)
except Exception as e:
    sys.exit(f"Error processing images: {e}")
