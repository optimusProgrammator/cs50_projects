"""
PYTHON PROGRAM : CAMEL CASE
"""

def main():
    camelCase = input("camelCase : ")
    snake_case = case(camelCase)
    print(snake_case)


def case(camel):
    snake = ""
    for char in camel:
        if char.isupper():
            snake += "_" + char.lower()
        else:
            snake += char
    return snake


if __name__ == "__main__":
    main()


#is upper()
