
def main():
    say = input("Greeting: ")
    amount = value(say)
    print(f"${amount}")

def value(greeting):
    match greeting.strip():
        case "Hello" | "Hello, Newman":
            return 0
        case "How you doing?" | "Hi":
            return 20
        case "What's happening?":
            return 100
        case _:
            return 100


if __name__ == "__main__":
    main()
