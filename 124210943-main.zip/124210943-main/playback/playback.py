"""
STRINGS PROGRAM : PLAYBACK
CREATED ON JULY 2, 2024
"""

def main():
    phrase = input("Playback a phrase: ")
    list = phrase.split()

    for word in list:
        print(f"{word}...", end="")



main()
