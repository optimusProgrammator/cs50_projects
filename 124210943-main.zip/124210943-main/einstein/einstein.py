"""
Python Program: Week 0: Einstein
"""

# Constant for the speed of light in meters per second
SPEED_OF_LIGHT = 300000000

def calculate_energy(mass):
    """Calculate energy using the formula E = m * c^2."""
    return mass * (SPEED_OF_LIGHT ** 2)

def mass_input():
    """Prompt the user to input mass and validate the input."""
    while True:
        try:
            mass = int(input("Input mass (in kilograms): "))
            if mass < 0:
                print("Mass cannot be negative. Please enter a positive value.")
            else:
                return mass
        except ValueError:
            print("Invalid input. Please enter an integer value.")

def main():
    """Main function to execute the program."""
    mass = mass_input()
    energy = calculate_energy(mass)
    print(energy)

main()
