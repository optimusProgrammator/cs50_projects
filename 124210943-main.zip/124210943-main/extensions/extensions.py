"""
PYTHON PROGRAM : EXTENSIONS
"""

def main():
    answer = input("Extension: ").lower()
    extension = determine(answer)
    print(extension)


def determine(thing):
    if ".jpg" in thing or ".jpeg" in thing:
        return "image/jpeg"
    if ".png" in thing:
        return "image/png"
    if ".gif" in thing:
        return "image/gif"
    if ".pdf" in thing:
        return "application/pdf"
    if ".txt" in thing:
        return "text/plain"
    if ".zip" in thing:
        return "application/zip"
    else:
        return "application/octet-stream"

if __name__ == "__main__":
    main()

