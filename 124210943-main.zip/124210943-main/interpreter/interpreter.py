"""
PYTHON PROGRAM : INTERPRETER
"""
def main():
    try:
        expression = input("Expression: ")
        elements = expression.split(" ")

        x = float(elements[0])
        y = elements[1]
        z = float(elements[2])

        result = operation(x,y,z)
        print(result)
    except ValueError as e:
        print(e)
    except ZeroDivisionError:
        print("Error: Division by zero is not allowed.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def operation(first, sign, second):
    if sign == "+":
        sum = first + second
        return sum
    elif sign == "-":
        difference = first - second
        return difference
    if sign == "*":
        product = first * second
        return product
    if sign == "/":
        quotient = first / second
        return quotient

if __name__ == "__main__":
    main()
