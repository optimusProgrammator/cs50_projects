from plates import is_valid

def main():
    test()

def test():
    # Basic valid cases
    assert is_valid("Hi") == True
    assert is_valid("Hello") == True
    assert is_valid("CS50") == True

    # Invalid cases
    assert is_valid("H") == False  # Too short
    assert is_valid("HelloWorld") == False  # Too long
    assert is_valid("1Hello") == False  # Doesn't start with two alphabetic characters
    assert is_valid("H3llo") == False  # Numbers not at the end
    assert is_valid("CS50CS") == False  # Numbers not at the end
    assert is_valid("CS05") == False  # First digit zero
    assert is_valid("CS!50") == False  # Non-alphanumeric characters

if __name__ == "__main__":
    main()
