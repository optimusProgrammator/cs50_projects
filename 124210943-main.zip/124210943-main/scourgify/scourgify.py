import sys
import csv

# Check the number of command-line arguments
if len(sys.argv) != 3:
    sys.exit("Usage: python scourgify.py input.csv output.csv")

# Get the input and output file names from the command-line arguments
input = sys.argv[1]
output = sys.argv[2]

try:
    # Try to open the input file and read its contents
    with open(input, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        students = []

        for row in reader:
            if 'name' in row and 'house' in row:
                last, first = row['name'].split(', ')
                house = row['house']
                students.append({'first': first, 'last': last, 'house': house})
            else:
                sys.exit(f"Incorrect columns in {input}")

except FileNotFoundError:
    sys.exit(f"Could not read {input}")
except Exception as e:
    sys.exit(f"Error reading {input}: {e}")

try:
    # Write the reformatted data to the output file
    with open(output, 'w', newline='') as csvfile:
        fieldnames = ['first', 'last', 'house']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(students)

except Exception as e:
    sys.exit(f"Could not write to {output}: {e}")

# If everything went well, exit with status code 0
sys.exit(0)
