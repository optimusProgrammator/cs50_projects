import csv
import os

class CSVHandler:
    def __init__(self, filename):
        self.filename = filename
        self.temp_filename = 'temp.csv'
        self.headers = ["Event Name", "Person Name", "Date (month, day, year format)"]

    def add_data(self, event_name, person_name, date):
        with open(self.filename, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([event_name, person_name, date])
        print(f"Added data: {[event_name, person_name, date]}")

    def edit_data(self, row_number, event_name, person_name, date):
        with open(self.filename, 'r', newline='') as csvfile, open(self.temp_filename, 'w', newline='') as temp_file:
            reader = csv.reader(csvfile)
            writer = csv.writer(temp_file)
            for index, row in enumerate(reader):
                if index == row_number:
                    writer.writerow([event_name, person_name, date])
                    print(f"Edited row {row_number}: {[event_name, person_name, date]}")
                else:
                    writer.writerow(row)
        os.replace(self.temp_filename, self.filename)

    def delete_data(self, row_number):
        with open(self.filename, 'r', newline='') as csvfile, open(self.temp_filename, 'w', newline='') as temp_file:
            reader = csv.reader(csvfile)
            writer = csv.writer(temp_file)
            for index, row in enumerate(reader):
                if index != row_number:
                    writer.writerow(row)
                else:
                    print(f"Deleted row {row_number}: {row}")
        os.replace(self.temp_filename, self.filename)

    def display_data(self):
        with open(self.filename, 'r', newline='') as csvfile:
            reader = csv.reader(csvfile)
            for index, row in enumerate(reader):
                print(f"{index}: {row}")

if __name__ == "__main__":
    filename = 'data.csv'

    # Create the file and write headers if it does not exist
    if not os.path.exists(filename):
        with open(filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Event Name", "Person Name", "Date (month, day, year format)"])

    handler = CSVHandler(filename)

    while True:
        print("\nOptions:\n1. Add Data\n2. Edit Data\n3. Delete Data\n4. Display Data\n5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            event_name = input("Enter event name: ")
            person_name = input("Enter person name: ")
            date = input("Enter date (month, day, year format): ")
            handler.add_data(event_name, person_name, date)
        elif choice == '2':
            row_number = int(input("Enter row number to edit: "))
            event_name = input("Enter new event name: ")
            person_name = input("Enter new person name: ")
            date = input("Enter new date (month, day, year format): ")
            handler.edit_data(row_number, event_name, person_name, date)
        elif choice == '3':
            row_number = int(input("Enter row number to delete: "))
            handler.delete_data(row_number)
        elif choice == '4':
            handler.display_data()
        elif choice == '5':
            break
        else:
            print("Invalid choice. Please try again.")
