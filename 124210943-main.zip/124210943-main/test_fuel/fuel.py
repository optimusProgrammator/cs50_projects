def main():
    fraction = input("Fraction: ")
    converted = convert(fraction)
    output = gauge(converted)
    print(output)

def convert(fraction):
    while True:
        try:
            parts = fraction.split("/")
            numerator = int(parts[0])
            denominator = int(parts[1])

            percentage = numerator / denominator

            if percentage <= 1:
                p = int(percentage * 100)
                return p
            else:
                fraction = input("Fraction: ")
                pass
        except:
            raise

def gauge(percentage):

    if percentage <= 1:
        return "E"
    elif percentage >= 99:
        return "F"
    else:
        return str(percentage) + "%"

if __name__ == "__main__":
    main()


