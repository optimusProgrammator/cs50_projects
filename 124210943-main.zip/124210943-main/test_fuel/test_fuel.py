import pytest
from fuel import convert, gauge

def main():
    test_percentage()
    test_zero()
    test_invalid()

def test_percentage():
    assert convert("1/2") == 50 and gauge(50) == "50%"
    assert convert("1/100") == 1 and gauge(1) == "E"
    assert convert("99/100") == 99 and gauge(99) == "F"

def test_zero():
    with pytest.raises(ZeroDivisionError):
        convert("1/0")

def test_invalid():
    with pytest.raises(ValueError):
        convert("cat/dog")

if __name__ == "__main__":
    main()

