import sys
import random
from pyfiglet import Figlet

def main():
    figlet = Figlet()
    if len(sys.argv) == 1:
        f = random.choice(figlet.getFonts())
    elif len(sys.argv) == 3:
        if sys.argv[1] in ["-f", "--font"]:
            f = sys.argv[2]
            if f not in figlet.getFonts():
                sys.exit("Invalid usage")
        else:
            sys.exit("Invalid usage")
    else:
        sys.exit("Invalid usage")

    figlet.setFont(font=f)

    text = input("Input: ")
    print(figlet.renderText(text))

if __name__ == "__main__":
    main()
