import math

def main():
    text = input("Text: ")

    letters = 0
    words = 0
    sentences = 0

    for char in text:
        if char.isalpha():
            letters += 1
        elif char == ' ':
            words += 1
        elif char in ['.', '?', '!']:
            sentences += 1

    L = float(letters / words) * 100
    S = float(sentences / words) * 100

    index = float(round(0.0588 * L - 0.296 * S - 15.8))

    if index < 1:
        print("Before Grade 1")
    elif index > 16:
        print("Grade 16+")
    else:
        print("Grade", index)

if __name__ == "__main__":
    main()
